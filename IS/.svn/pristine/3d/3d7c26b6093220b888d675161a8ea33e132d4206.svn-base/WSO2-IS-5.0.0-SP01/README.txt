Patch ID        : WSO2-IS-5.0.0-SP01
Applies To      : WSO2 Identity Server 5.0.0

INTRODUCTION
============

This Service Pack(SP) contains all the fixes issued for WSO2 Identity Server 5.0.0 
up to WSO2-CARBON-PATCH-4.2.0-1016.


INSTALLATION INSTRUCTIONS
=========================

Follow the installation instructions given below, to install this SP in your environment.

Installing the service pack into a fresh WSO2 Identity Server 5.0.0 release, prior to the first startup.
========================================================================================================


1. Download WSO2 Identity Server 5.0.0 (wso2is-5.0.0.zip) and extract it to a desired location. 
   Download WSO2-IS-5.0.0-SP01.zip, extract it and copy the WSO2-IS-5.0.0-SP01 directory to the same location,
   where you have wso2is-5.0.0.

   The directory structure, from the parent directory will look like following.

	     /----
               |--wso2is-5.0.0
               |--WSO2-IS-5.0.0-SP01

2. In the command line, from the 'WSO2-IS-5.0.0-SP01' directory run the following command.

   On Microsoft Windows:   

   \> install_sp.bat

   On Linux/Unix:   

   $ sh install_sp.sh
   
3. Start the Identity Server.

    Linux/Unix :   $ sh wso2server.sh -Dsetup
    Windows    :   \> wso2server.bat -Dsetup

4. Open the file, wso2is-5.0.0/repository/logs/patches.log and look for the following line. If you find it,
   that means the service pack has been applied successfully.

   INFO {org.wso2.carbon.server.util.PatchUtils} -  Applying - patch1016

Installing the service pack into a WSO2 Identity Server 5.0.0 release, in production already.
=============================================================================================

1. If you are already running the WSO2 Identity Server 5.0.0, gracefully shutdown it.

2. Unzip the zip distribution of the service pack (WSO2-IS-5.0.0-SP01.zip) and copy 
   the artifacts from it to the Identity Server distribution, as explained below.

    NOTE-1: If an artifact from the patch is replacing an existing artifact in the server, 
            take a backup of the old artifact and remove it from Identity Server.


3. Copy the WSO2-IS-5.0.0-SP01/wso2carbon-version.txt file to IS_HOME/bin/

4. Copy the directory WSO2-IS-5.0.0-SP01/patch1016 to IS_HOME/repository/components/patches/
 
5. Copy oauth2.war and wso2.war files from WSO2-IS-5.0.0-SP01/resources/webapps, 
   to IS_HOME/repository/deployment/server/webapps/ directory. Remove the extracted folders 'oauth2' and 'wso2' if exist.
   

6. Copy authenticationendpoint.war file from WSO2-IS-5.0.0-SP01/resources/webapps, 
   to IS_HOME/repository/deployment/server/webapps/ directory.

   NOTE-2:  If the the current authenticationendpoint.war is customized, go through the diff files attached 
            to https://wso2.org/jira/browse/IDENTITY-2903 and apply the fix - without directly replacing it with 
            the one ships with the service pack.

7. Copy the jar files from WSO2-IS-5.0.0-SP01/resources/lib to IS_HOME/lib/ folder.
 
8. Copy WSO2-IS-5.0.0-SP01/resources/samlsso_federate.html  to IS_HOME/repository/resources/security/ directory.

9. Make the following configuration changes.

   Add the following property(GetAllRolesOfUserEnabled) to IS_HOME/repository/conf/user-mgt.xml file under AuthorizationManager   
   configuration element.This property would improve the performance when user store has few roles in its search base.
			
   <AuthorizationManager class="org.wso2.carbon.user.core.authorization.JDBCAuthorizationManager">

      <Property name="GetAllRolesOfUserEnabled">true</Property>

   </AuthorizationManager>

10. Make the following database modifications. 
    
    Execute the corresponding database script related to your database engine from WSO2-IS-5.0.0-SP01/resources/dbscripts_mod. 
    Inside dbscripts_mod, there are two levels, make sure you execute all of them appropriately. Please execute only the
    database changes that are not applied already by a previous patch. (ex. patch0777).

     - WSO2-IS-5.0.0-SP01/resources/dbscripts_mod/identity
     - WSO2-IS-5.0.0-SP01/resources/dbscripts_mod/identity/application-mgt

11. Start the Identity Server.

    Linux/Unix :  $ sh wso2server.sh
    Windows    :  \> wso2server.bat


12. Open the file, wso2is-5.0.0/repository/logs/patches.log and look for the following line. If you find it,
    that means the service pack has been applied successfully.

    INFO {org.wso2.carbon.server.util.PatchUtils} -  Applying - patch1016


FIXES
=====

Following list of patches are included in the SP.

-------------------------------------------------------------------------
|Patch Number		      |		Associated JIRA                 |
-------------------------------------------------------------------------	 	 	
WSO2-CARBON-PATCH-4.2.0-0105 	https://wso2.org/jira/browse/CARBON-14528
WSO2-CARBON-PATCH-4.2.0-0146 	https://wso2.org/jira/browse/CARBON-14651
WSO2-CARBON-PATCH-4.2.0-0186 	https://wso2.org/jira/browse/CARBON-14677
WSO2-CARBON-PATCH-4.2.0-0197 	https://wso2.org/jira/browse/CARBON-14729
WSO2-CARBON-PATCH-4.2.0-0199 	https://wso2.org/jira/browse/CARBON-14730
WSO2-CARBON-PATCH-4.2.0-0209 	https://wso2.org/jira/browse/CARBON-14740
WSO2-CARBON-PATCH-4.2.0-0210 	https://wso2.org/jira/browse/CARBON-14505
WSO2-CARBON-PATCH-4.2.0-0241 	https://wso2.org/jira/browse/CARBON-14743
WSO2-CARBON-PATCH-4.2.0-0266 	https://wso2.org/jira/browse/CARBON-14743
WSO2-CARBON-PATCH-4.2.0-0276 	https://wso2.org/jira/browse/CARBON-14768
WSO2-CARBON-PATCH-4.2.0-0281 	https://wso2.org/jira/browse/CARBON-14776
WSO2-CARBON-PATCH-4.2.0-0282 	https://wso2.org/jira/browse/CARBON-14783 	
WSO2-CARBON-PATCH-4.2.0-0301 	https://wso2.org/jira/browse/CARBON-14769
WSO2-CARBON-PATCH-4.2.0-0302 	https://wso2.org/jira/browse/CARBON-14795
WSO2-CARBON-PATCH-4.2.0-0303 	https://wso2.org/jira/browse/CARBON-14796
WSO2-CARBON-PATCH-4.2.0-0321 	https://wso2.org/jira/browse/CARBON-14814
WSO2-CARBON-PATCH-4.2.0-0335 	https://wso2.org/jira/browse/IDENTITY-2075
WSO2-CARBON-PATCH-4.2.0-0362 	https://wso2.org/jira/browse/CARBON-14511
WSO2-CARBON-PATCH-4.2.0-0363 	https://wso2.org/jira/browse/IDENTITY-2551
WSO2-CARBON-PATCH-4.2.0-0384 	https://wso2.org/jira/browse/CARBON-14802
WSO2-CARBON-PATCH-4.2.0-0395 	https://wso2.org/jira/browse/CARBON-14832
WSO2-CARBON-PATCH-4.2.0-0398 	https://wso2.org/jira/browse/CARBON-14703
WSO2-CARBON-PATCH-4.2.0-0413 	https://wso2.org/jira/browse/IDENTITY-2588
WSO2-CARBON-PATCH-4.2.0-0416 	https://wso2.org/jira/browse/CARBON-14852
WSO2-CARBON-PATCH-4.2.0-0436 	https://wso2.org/jira/browse/IDENTITY-2600
WSO2-CARBON-PATCH-4.2.0-0440 	https://wso2.org/jira/browse/CARBON-14861
WSO2-CARBON-PATCH-4.2.0-0444 	https://wso2.org/jira/browse/IDENTITY-2604
WSO2-CARBON-PATCH-4.2.0-0448 	https://wso2.org/jira/browse/IDENTITY-2612
WSO2-CARBON-PATCH-4.2.0-0450 	https://wso2.org/jira/browse/IDENTITY-2613
WSO2-CARBON-PATCH-4.2.0-0463 	https://wso2.org/jira/browse/IDENTITY-2615
WSO2-CARBON-PATCH-4.2.0-0468 	https://wso2.org/jira/browse/IDENTITY-2617
WSO2-CARBON-PATCH-4.2.0-0493 	https://wso2.org/jira/browse/CARBON-14841
WSO2-CARBON-PATCH-4.2.0-0505 	https://wso2.org/jira/browse/IDENTITY-2617
WSO2-CARBON-PATCH-4.2.0-0511 	https://wso2.org/jira/browse/IDENTITY-2600, 
			        https://wso2.org/jira/browse/IDENTITY-2604
WSO2-CARBON-PATCH-4.2.0-0512 	https://wso2.org/jira/browse/CARBON-14888
WSO2-CARBON-PATCH-4.2.0-0522 	https://wso2.org/jira/browse/IDENTITY-2623
WSO2-CARBON-PATCH-4.2.0-0524 	https://wso2.org/jira/browse/CARBON-14911
WSO2-CARBON-PATCH-4.2.0-0531 	https://wso2.org/jira/browse/CARBON-14894
WSO2-CARBON-PATCH-4.2.0-0540 	https://wso2.org/jira/browse/CARBON-14859
WSO2-CARBON-PATCH-4.2.0-0541 	https://wso2.org/jira/browse/IDENTITY-2656
WSO2-CARBON-PATCH-4.2.0-0543 	https://wso2.org/jira/browse/CARBON-14876
WSO2-CARBON-PATCH-4.2.0-0553 	https://wso2.org/jira/browse/IDENTITY-2654
WSO2-CARBON-PATCH-4.2.0-0564 	https://wso2.org/jira/browse/CARBON-14907
WSO2-CARBON-PATCH-4.2.0-0574 	https://wso2.org/jira/browse/CARBON-14909	
WSO2-CARBON-PATCH-4.2.0-0587 	https://wso2.org/jira/browse/CARBON-14912
WSO2-CARBON-PATCH-4.2.0-0597 	https://wso2.org/jira/browse/CARBON-14914
WSO2-CARBON-PATCH-4.2.0-0599 	https://wso2.org/jira/browse/IDENTITY-2588
WSO2-CARBON-PATCH-4.2.0-0603 	https://wso2.org/jira/browse/IDENTITY-2675
WSO2-CARBON-PATCH-4.2.0-0606 	https://wso2.org/jira/browse/CARBON-14916
WSO2-CARBON-PATCH-4.2.0-0618 	https://wso2.org/jira/browse/IDENTITY-2688
WSO2-CARBON-PATCH-4.2.0-0621 	https://wso2.org/jira/browse/IDENTITY-2691
WSO2-CARBON-PATCH-4.2.0-0623 	https://wso2.org/jira/browse/REGISTRY-2147
WSO2-CARBON-PATCH-4.2.0-0632 	https://wso2.org/jira/browse/IDENTITY-2700
WSO2-CARBON-PATCH-4.2.0-0642 	https://wso2.org/jira/browse/IDENTITY-2702
WSO2-CARBON-PATCH-4.2.0-0645 	https://wso2.org/jira/browse/IDENTITY-2704
WSO2-CARBON-PATCH-4.2.0-0648 	https://wso2.org/jira/browse/IDENTITY-2707 	
WSO2-CARBON-PATCH-4.2.0-0651 	https://wso2.org/jira/browse/IDENTITY-2680,
			        https://wso2.org/jira/browse/IDENTITY-2684
WSO2-CARBON-PATCH-4.2.0-0654 	https://wso2.org/jira/browse/IDENTITY-2711
WSO2-CARBON-PATCH-4.2.0-0656 	https://wso2.org/jira/browse/IDENTITY-2714
WSO2-CARBON-PATCH-4.2.0-0657 	https://wso2.org/jira/browse/IDENTITY-2664
WSO2-CARBON-PATCH-4.2.0-0665 	https://wso2.org/jira/browse/CARBON-14946
WSO2-CARBON-PATCH-4.2.0-0667 	https://wso2.org/jira/browse/IDENTITY-2573
WSO2-CARBON-PATCH-4.2.0-0668 	https://wso2.org/jira/browse/IDENTITY-2573
WSO2-CARBON-PATCH-4.2.0-0671 	https://wso2.org/jira/browse/IDENTITY-2721
WSO2-CARBON-PATCH-4.2.0-0678 	https://wso2.org/jira/browse/IDENTITY-2694
WSO2-CARBON-PATCH-4.2.0-0684 	https://wso2.org/jira/browse/CARBON-14959
WSO2-CARBON-PATCH-4.2.0-0687 	https://wso2.org/jira/browse/CARBON-14960
WSO2-CARBON-PATCH-4.2.0-0690 	https://wso2.org/jira/browse/IDENTITY-2740
WSO2-CARBON-PATCH-4.2.0-0694 	https://wso2.org/jira/browse/CARBON-14963
WSO2-CARBON-PATCH-4.2.0-0703 	https://wso2.org/jira/browse/CARBON-14946
WSO2-CARBON-PATCH-4.2.0-0712 	https://wso2.org/jira/browse/IDENTITY-2721
WSO2-CARBON-PATCH-4.2.0-0728 	https://wso2.org/jira/browse/CARBON-14980
WSO2-CARBON-PATCH-4.2.0-0735 	https://wso2.org/jira/browse/IDENTITY-2275
WSO2-CARBON-PATCH-4.2.0-0738 	https://wso2.org/jira/browse/IDENTITY-2757
WSO2-CARBON-PATCH-4.2.0-0746 	https://wso2.org/jira/browse/IDENTITY-2766 	
WSO2-CARBON-PATCH-4.2.0-0761 	https://wso2.org/jira/browse/CARBON-15003
WSO2-CARBON-PATCH-4.2.0-0767 	https://wso2.org/jira/browse/CARBON-14963
WSO2-CARBON-PATCH-4.2.0-0770 	https://wso2.org/jira/browse/CARBON-15009
WSO2-CARBON-PATCH-4.2.0-0774	https://wso2.org/jira/browse/JAGGERY-356
WSO2-CARBON-PATCH-4.2.0-0792 	https://wso2.org/jira/browse/CARBON-14963
WSO2-CARBON-PATCH-4.2.0-0794 	https://wso2.org/jira/browse/IDENTITY-2794
WSO2-CARBON-PATCH-4.2.0-0801 	https://wso2.org/jira/browse/IDENTITY-2800
WSO2-CARBON-PATCH-4.2.0-0802 	https://wso2.org/jira/browse/CARBON-15017,
			        https://wso2.org/jira/browse/CARBON-15022
WSO2-CARBON-PATCH-4.2.0-0805 	https://wso2.org/jira/browse/IDENTITY-2805
WSO2-CARBON-PATCH-4.2.0-0814 	https://wso2.org/jira/browse/IDENTITY-2808
WSO2-CARBON-PATCH-4.2.0-0816 	https://wso2.org/jira/browse/CARBON-15028
WSO2-CARBON-PATCH-4.2.0-0819 	https://wso2.org/jira/browse/IDENTITY-2787,
				https://wso2.org/jira/browse/CARBON-15029
WSO2-CARBON-PATCH-4.2.0-0822 	https://wso2.org/jira/browse/IDENTITY-2796
WSO2-CARBON-PATCH-4.2.0-0823 	https://wso2.org/jira/browse/APIMANAGER-2630
WSO2-CARBON-PATCH-4.2.0-0824 	https://wso2.org/jira/browse/IDENTITY-2801,
				https://wso2.org/jira/browse/IDENTITY-2802
WSO2-CARBON-PATCH-4.2.0-0825 	https://wso2.org/jira/browse/IDENTITY-2814
WSO2-CARBON-PATCH-4.2.0-0832 	https://wso2.org/jira/browse/IDENTITY-2800,
				https://wso2.org/jira/browse/IDENTITY-2817
WSO2-CARBON-PATCH-4.2.0-0838 	https://wso2.org/jira/browse/IDENTITY-2821
WSO2-CARBON-PATCH-4.2.0-0841 	https://wso2.org/jira/browse/IDENTITY-2820
WSO2-CARBON-PATCH-4.2.0-0846 	https://wso2.org/jira/browse/CARBON-15034
WSO2-CARBON-PATCH-4.2.0-0847 	https://wso2.org/jira/browse/IDENTITY-1898
WSO2-CARBON-PATCH-4.2.0-0849 	https://wso2.org/jira/browse/IDENTITY-2824
WSO2-CARBON-PATCH-4.2.0-0857 	https://wso2.org/jira/browse/CARBON-15038
WSO2-CARBON-PATCH-4.2.0-0859	https://wso2.org/jira/browse/CARBON-15048
WSO2-CARBON-PATCH-4.2.0-0867	https://wso2.org/jira/browse/CARBON-15051
WSO2-CARBON-PATCH-4.2.0-0869	https://wso2.org/jira/browse/IDENTITY-2857
WSO2-CARBON-PATCH-4.2.0-0880	https://wso2.org/jira/browse/CARBON-15041
WSO2-CARBON-PATCH-4.2.0-0881	https://wso2.org/jira/browse/IDENTITY-2789
WSO2-CARBON-PATCH-4.2.0-0882	https://wso2.org/jira/browse/IDENTITY-2866
WSO2-CARBON-PATCH-4.2.0-0883	https://wso2.org/jira/browse/IDENTITY-2873
WSO2-CARBON-PATCH-4.2.0-0887	https://wso2.org/jira/browse/IDENTITY-2882
WSO2-CARBON-PATCH-4.2.0-0896	https://wso2.org/jira/browse/IDENTITY-2879
WSO2-CARBON-PATCH-4.2.0-0902	https://wso2.org/jira/browse/CARBON-14819
WSO2-CARBON-PATCH-4.2.0-0905	https://wso2.org/jira/browse/IDENTITY-2882
WSO2-CARBON-PATCH-4.2.0-0908	https://wso2.org/jira/browse/IDENTITY-2892
WSO2-CARBON-PATCH-4.2.0-0917	https://wso2.org/jira/browse/IDENTITY-2902
WSO2-CARBON-PATCH-4.2.0-0929	https://wso2.org/jira/browse/APIMANAGER-3125
WSO2-CARBON-PATCH-4.2.0-0930	https://wso2.org/jira/browse/IDENTITY-2919
WSO2-CARBON-PATCH-4.2.0-0938	https://wso2.org/jira/browse/IDENTITY-2888
WSO2-CARBON-PATCH-4.2.0-0948	https://wso2.org/jira/browse/CARBON-15076
WSO2-CARBON-PATCH-4.2.0-0951
WSO2-CARBON-PATCH-4.2.0-0960	https://wso2.org/jira/browse/WSAS-1854
WSO2-CARBON-PATCH-4.2.0-0964	https://wso2.org/jira/browse/CARBON-15100
WSO2-CARBON-PATCH-4.2.0-0967	https://wso2.org/jira/browse/IDENTITY-2789
WSO2-CARBON-PATCH-4.2.0-0975 	https://wso2.org/jira/browse/IDENTITY-2923
WSO2-CARBON-PATCH-4.2.0-0982 	https://wso2.org/jira/browse/BAM-1747, https://wso2.org/jira/browse/BAM-1748
WSO2-CARBON-PATCH-4.2.0-0987 	https://wso2.org/jira/browse/CARBON-15046 
WSO2-CARBON-PATCH-4.2.0-0991 	https://wso2.org/jira/browse/IDENTITY-2951
WSO2-CARBON-PATCH-4.2.0-0992 	https://wso2.org/jira/browse/IDENTITY-1891, https://wso2.org/jira/browse/IDENTITY-2954
WSO2-CARBON-PATCH-4.2.0-0997 	https://wso2.org/jira/browse/CARBON-15112
WSO2-CARBON-PATCH-4.2.0-1000 	https://wso2.org/jira/browse/CARBON-15111
WSO2-CARBON-PATCH-4.2.0-1012 	https://wso2.org/jira/browse/CARBON-15127
WSO2-CARBON-PATCH-4.2.0-1013 	https://wso2.org/jira/browse/CARBON-15130
