UPDATE IDP_AUTHENTICATOR SET NAME='samlsso' WHERE NAME = 'saml2sso' AND TENANT_ID = '-1234'

/*

	(i) Run the following query and get the constraint_name
            SELECT CONSTRAINT_NAME FROM INFORMATION_SCHEMA.CONSTRAINTS WHERE TABLE_NAME='IDP_PROVISIONING_ENTITY' AND COLUMN_LIST ='ENTITY_TYPE,TENANT_ID,ENTITY_LOCAL_USERSTORE,ENTITY_NAME';
        
        (ii)Run the following query to drop the existing constraint. Replace <constraining_name> from above findings. 
            ALTER TABLE IDP_PROVISIONING_ENTITY  DROP CONSTRAINT <constraining_name>; 

        (iii)Run the following query to create new unique key constriant
            CREATE UNIQUE INDEX PUBLIC.CONSTRAINT_INDEX_C2 ON PUBLIC.IDP_PROVISIONING_ENTITY(ENTITY_TYPE, TENANT_ID, ENTITY_LOCAL_USERSTORE, ENTITY_NAME, PROVISIONING_CONFIG_ID);
*/
