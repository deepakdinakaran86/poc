UPDATE IDP_AUTHENTICATOR SET NAME='samlsso' WHERE NAME = 'saml2sso' AND TENANT_ID = '-1234';

/*
	(i) Run the following query to find required constraint.
 
            	SP_HELP IDP_PROVISIONING_ENTITY;
            
            This will list down the table structure and find the constraint name of the constraint which is relevent to 'UNIQUE (ENTITY_TYPE, TENANT_ID, ENTITY_LOCAL_USERSTORE, ENTITY_NAME)'.

        (ii) Run the following query to drop the existing constraint. replace <constraint_name> from above findings

            	ALTER TABLE IDP_PROVISIONING_ENTITY DROP CONSTRAINT <constraint name>;

        (iii) Run the following query to create a new constraint.

            	ALTER TABLE IDP_PROVISIONING_ENTITY ADD CONSTRAINT <constraint name> UNIQUE(ENTITY_TYPE, TENANT_ID, ENTITY_LOCAL_USERSTORE, ENTITY_NAME, PROVISIONING_CONFIG_ID);
*/
