#!/bin/bash
# ----------------------------------------------------------------------------
#  Copyright 2005-2014 WSO2, Inc. http://www.wso2.org
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
# ----------------------------------------------------------------------------


echo " "
read -p "[Warning] This Service Pack is only for a fresh Identity Server installation! This will override all the existing configuration files and will delete the internal H2 database.

Do you want to continue ? [y/n]:" answer
if [ "$answer" = "y" ] ; then

printf "\n\n"
echo "---------------------------------------------------------------------------------------------"
echo "-                                  WSO2 Identity Server SP1                                 -"
echo "---------------------------------------------------------------------------------------------"
printf "\n\n"
echo "............................................................................................."
printf "\n"	
echo "Copying the wso2carbon-version.txt file to <CARBON_SERVER>/bin."
cp wso2carbon-version.txt ../wso2is-5.0.0/bin
if [ "$?" != "0" ]; then
    echo "[Error] Copying the wso2carbon-version.txt file failed." 1>&2
    exit 0 
fi
printf "\n"
echo "............................................................................................."
printf "\n"	

echo "Copying the patch1016 to <CARBON_SERVER>/repository/components/patches/"
cp -r patch1016 ../wso2is-5.0.0/repository/components/patches/
if [ "$?" != "0" ]; then
    echo "[Error] Copying the patch1016 failed." 1>&2
    exit -1 
fi
printf "\n"
echo "............................................................................................."
printf "\n"

echo "Copying oauth2.war ,authenticationendpoint.war and wso2.war files inside resources/webapps of the patch, to <CARBON_SERVER>/repository/deployment/server/webapps/ folder." 
cp resources/webapps/*  ../wso2is-5.0.0/repository/deployment/server/webapps/
if [ "$?" != "0" ]; then
    echo "[Error] Copying oauth2.war ,authenticationendpoint.war and wso2.war files inside resources/webapps of the patch failed." 1>&2
    exit  0
fi
printf "\n"
echo "............................................................................................."
printf "\n"

echo "Copying the sql script files inside resources/dbscripts/identity folder of the patch to <CARBON_SERVER>/dbscripts/identity folder."
cp -r resources/dbscripts  ../wso2is-5.0.0/
if [ "$?" != "0" ]; then
    echo "[Error] Copying the sql script files inside resources/dbscripts/identity folder of the patch failed." 1>&2
    exit 1 
fi
printf "\n"
echo "............................................................................................."
printf "\n"

echo "Copying the jar files inside resources/lib folder of the patch to <CARBON_SERVER>/lib/ folder."
cp -r resources/lib/*.jar ../wso2is-5.0.0/lib/
if [ "$?" != "0" ]; then
    echo "[Error] Copying the jar files inside resources/lib folder of the patch failed." 1>&2
    exit  1
fi
printf "\n"
echo "............................................................................................."
printf "\n"

echo "Copying 'samlsso_federate.html' file inside 'resources' folder of the patch to <CARBON_SERVER>/repository/resources/security/ folder."
cp resources/samlsso_federate.html ../wso2is-5.0.0/repository/resources/security/
if [ "$?" != "0" ]; then
    echo "[Error] Copying 'samlsso_federate.html' file inside 'resources' folder of the patch failed." 1>&2
    exit 1 
fi
printf "\n"
echo "............................................................................................."
printf "\n"

echo "Copying configuration files inside 'resources/conf' folder of the patch to <CARBON_SERVER>/repository/conf/ folder."
cp -r resources/conf/* ../wso2is-5.0.0/repository/conf/
if [ "$?" != "0" ]; then
    echo "[Error] Copying configuration files inside 'resources/conf' folder of the patch failed." 1>&2
    exit  1
fi
printf "\n"
echo "............................................................................................."
printf "\n"

echo "Copying updated H2 database to repository/databases"
rm ../wso2is-5.0.0/repository/database/WSO2CARBON_DB.h2.db
cp -r resources/database/ ../wso2is-5.0.0/repository/
if [ "$?" != "0" ]; then
    echo "[Error] Copying updated H2 database to repository/databases/ failed." 1>&2
    exit  1
fi
printf "\n"
echo "............................................................................................."

fi

