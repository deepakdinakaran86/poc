package com.hazelcast.demo;

/**
 * Created by mesutcelik on 6/16/14.
 */
public class Simple {
    public static void main(String[] args) {
        System.out.println("hey");
    }
}
