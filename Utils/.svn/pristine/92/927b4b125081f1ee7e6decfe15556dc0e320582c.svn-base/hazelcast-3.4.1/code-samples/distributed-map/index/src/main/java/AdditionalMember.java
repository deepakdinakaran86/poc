import com.hazelcast.core.Hazelcast;

public class AdditionalMember {
    public static void main(String[] args) {
        Hazelcast.newHazelcastInstance();
    }
}
