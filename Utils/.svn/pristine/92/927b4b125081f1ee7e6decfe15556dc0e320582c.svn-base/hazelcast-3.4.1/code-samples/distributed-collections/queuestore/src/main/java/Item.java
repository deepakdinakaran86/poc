import java.io.Serializable;

public class Item implements Serializable {
}
